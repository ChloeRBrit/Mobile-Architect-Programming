package com.example.inventorys;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class InventoryAdapter extends ArrayAdapter<String> {

    private final Context context;
    private final String[] values;

    // Constructor for the adapter
    public InventoryAdapter(Context context, String[] values) {
        super(context, R.layout.inventory_grid_item, values);
        this.context = context;
        this.values = values;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.inventory_grid_item, parent, false);
        }

        TextView itemText = convertView.findViewById(R.id.item_text);
        itemText.setText(values[position]);

        return convertView;
    }
}