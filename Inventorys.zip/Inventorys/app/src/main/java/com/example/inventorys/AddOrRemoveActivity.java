package com.example.inventorys;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddOrRemoveActivity extends AppCompatActivity {
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_or_remove);
        db = new DatabaseHelper(this);

        EditText itemName = findViewById(R.id.item_name);
        EditText quantity = findViewById(R.id.item_quantity);
        Button addButton = findViewById(R.id.add_item_button);
        Button updateButton = findViewById(R.id.remove_item_button);

        addButton.setOnClickListener(v -> {
            String name = itemName.getText().toString();
            String qtyStr = quantity.getText().toString();

            if (!name.isEmpty() && !qtyStr.isEmpty()) {
                int qty = Integer.parseInt(qtyStr);
                // Add the item to the database
                db.addItem(name, qty); // Implement this method in your DatabaseHelper
                Toast.makeText(this, "Item Added!", Toast.LENGTH_SHORT).show();
                returnToInventory();
            } else {
                Toast.makeText(this, "Please enter item name and quantity!", Toast.LENGTH_SHORT).show();
            }
        });

        updateButton.setOnClickListener(v -> {
            String name = itemName.getText().toString();
            String qtyStr = quantity.getText().toString();

            if (!name.isEmpty() && !qtyStr.isEmpty()) {
                int qty = Integer.parseInt(qtyStr);
                // Update the item's quantity in the database
                db.updateItemQuantity(name, qty); // Implement this method in your DatabaseHelper
                Toast.makeText(this, "Item Updated!", Toast.LENGTH_SHORT).show();
                returnToInventory();
            } else {
                Toast.makeText(this, "Please enter item name and quantity!", Toast.LENGTH_SHORT).show();
            }
        });
        updateButton.setOnClickListener(v -> {
            String name = itemName.getText().toString();

            if (!name.isEmpty()) {
                // Delete the item from the database
                db.deleteItem(name);
                Toast.makeText(this, "Item Deleted!", Toast.LENGTH_SHORT).show();
                returnToInventory();
            } else {
                Toast.makeText(this, "Please enter item name to delete!", Toast.LENGTH_SHORT).show();
            }
        });

    }


    private void returnToInventory() {
        Intent intent = new Intent(this, InventoryActivity.class); // Replace with your InventoryActivity class
        startActivity(intent);
        finish(); // Optional: Close this activity
    }
}