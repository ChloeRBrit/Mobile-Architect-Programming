package com.example.inventorys;

import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private static final int PERMISSION_REQUEST_CODE = 1;
    private static final String PREFS_NAME = "MyAppPreferences";
    private static final String KEY_FIRST_TIME = "isFirstTime";

    private TextView textView;
    private EditText editTextPhone;
    private EditText editTextMessage;
    private Button sendButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.headerTextView);
        editTextPhone = findViewById(R.id.editTextPhone);
        editTextMessage = findViewById(R.id.editTextMessage);
        sendButton = findViewById(R.id.Sendbutton);

        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean isFirstTime = sharedPreferences.getBoolean(KEY_FIRST_TIME, true);

        if (isFirstTime) {
            // Display the SMS input form
            textView.setText("Enter phone number and message to send SMS");
            sendButton.setVisibility(View.VISIBLE);

            sendButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    handleSendSMS();
                }
            });

            // Update SharedPreferences to indicate that the SMS screen has been shown
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(KEY_FIRST_TIME, false);
            editor.apply();
        } else {
            // Hide the SMS input form for subsequent launches
            textView.setText("Welcome back!");
            editTextPhone.setVisibility(View.GONE);
            editTextMessage.setVisibility(View.GONE);
            sendButton.setVisibility(View.GONE);

            // Start the InventoryActivity after a short delay
            new android.os.Handler().postDelayed(() -> {
                Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
                startActivity(intent);
                finish();  // Finish the current activity so it can't be returned to
            }, 2000); // Adjust the delay as needed
        }
    }

    private void handleSendSMS() {
        String phoneNumber = editTextPhone.getText().toString();
        String message = editTextMessage.getText().toString();

        Log.d(TAG, "Phone number: " + phoneNumber);
        Log.d(TAG, "Message: " + message);

        // Check if permission is granted
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // Request permission
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_REQUEST_CODE);
        } else {
            // Permission is already granted, send the SMS
            sendSMS(phoneNumber, message);
        }
    }

    private void sendSMS(String phoneNumber, String message) {
        SmsManager smsManager = SmsManager.getDefault();
        try {
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            textView.setText("SMS sent");
            Log.d(TAG, "SMS sent successfully");
            // Start the next activity
            Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
            startActivity(intent);
            finish();  // Finish the current activity so it can't be returned to

        } catch (Exception e) {
            textView.setText("SMS failed to send");
            Log.e(TAG, "SMS failed to send", e);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG, "SMS permission granted");
                // Permission granted, retry sending the SMS
                String phoneNumber = editTextPhone.getText().toString();
                String message = editTextMessage.getText().toString();
                sendSMS(phoneNumber, message);
            } else {
                Log.d(TAG, "SMS permission denied");
                textView.setText("SMS permission denied");
            }
        }
    }
}