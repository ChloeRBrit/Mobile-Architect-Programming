package com.example.inventorys;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;


import android.content.Intent;


import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private GridView inventoryGrid;
    private Button updateButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventory_screen);

        inventoryGrid = findViewById(R.id.inventory_grid);
        updateButton = findViewById(R.id.update_button);

        DatabaseHelper dbHelper = new DatabaseHelper(this);
        Cursor cursor = dbHelper.getAllItems();

        if (cursor != null && cursor.moveToFirst()) {
            // Extract data from the cursor
            List<String> itemList = new ArrayList<>();
            do {
                String itemName = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_ITEM_NAME));
                itemList.add(itemName);

            } while (cursor.moveToNext());
            cursor.close(); // Always close the cursor


            // Create an adapter and set it to the GridView
            InventoryAdapter adapter = new InventoryAdapter(this, itemList.toArray(new String[0]));
            inventoryGrid.setAdapter(adapter);
        }

            updateButton.setOnClickListener(v -> {
                // Handle the update button click
                Toast.makeText(this, "Update button clicked!", Toast.LENGTH_SHORT).show();

                // Start UpdateActivity
                Intent intent = new Intent(InventoryActivity.this, AddOrRemoveActivity.class);
                startActivity(intent);
            });
        }
    }